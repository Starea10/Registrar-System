-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2026 at 07:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `request_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `archive_history`
--

CREATE TABLE `archive_history` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `claiming_date` date DEFAULT NULL,
  `requester_id` int(11) DEFAULT NULL,
  `source` enum('walkin','online') NOT NULL DEFAULT 'walkin',
  `status` enum('pending','processing','for_signature','for_release','released') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `student_number` varchar(50) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT 0,
  `released_at` datetime DEFAULT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `email_address` varchar(128) DEFAULT NULL,
  `student_id_image` varchar(255) DEFAULT NULL,
  `registration_form_image` varchar(255) DEFAULT NULL,
  `clearance_form_image` varchar(255) DEFAULT NULL,
  `proof_of_graduation_image` varchar(255) DEFAULT NULL,
  `id_picture_image` varchar(255) DEFAULT NULL,
  `honorable_dismissal_image` varchar(255) DEFAULT NULL,
  `government_id_image` varchar(255) DEFAULT NULL,
  `original_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image_2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE `audit_trail` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_trail`
--

INSERT INTO `audit_trail` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES
(1, 1, 'remove_landing_image', 'Removed landing page slide #6', '2026-09-21 05:10:34'),
(2, 1, 'remove_landing_image', 'Removed landing page slide #5', '2026-09-21 05:10:44'),
(3, 1, 'remove_landing_image', 'Removed landing page slide #2', '2026-09-21 05:10:46'),
(4, 1, 'remove_landing_image', 'Removed landing page slide #3', '2026-09-21 05:10:47'),
(5, 1, 'remove_landing_image', 'Removed landing page slide #4', '2026-09-21 05:10:49'),
(6, 1, 'add_landing_image', 'Added a new landing page slide', '2026-09-21 05:11:59'),
(7, 1, 'remove_landing_image', 'Removed landing page slide #7', '2026-09-21 05:13:26'),
(8, 1, 'add_landing_image', 'Added a new landing page slide', '2026-09-21 05:14:08'),
(9, 1, 'remove_landing_image', 'Removed landing page slide #1', '2026-09-21 05:14:23'),
(10, 1, 'add_landing_image', 'Added a new landing page slide', '2026-09-21 05:14:44'),
(11, 1, 'remove_landing_image', 'Removed landing page slide #8', '2026-09-21 05:15:03'),
(12, 1, 'add_landing_image', 'Added a new landing page slide', '2026-09-21 05:17:17'),
(13, 1, 'remove_landing_image', 'Removed landing page slide #9', '2026-09-21 05:25:18'),
(14, 1, 'add_landing_image', 'Added a new landing page slide', '2026-09-21 05:25:30'),
(15, 1, 'remove_landing_image', 'Removed landing page slide #10', '2026-09-21 05:25:32'),
(16, 1, 'remove_staff', 'Removed staff member: TEst', '2026-09-21 05:26:25'),
(17, 1, 'add_program', 'Added program: 000 - TEST', '2026-09-21 05:26:37'),
(18, 1, 'edit_program', 'Edited program 000: now \"TEST1\"', '2026-09-21 05:26:43'),
(19, 1, 'delete_program', 'Deleted program: 000', '2026-09-21 05:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `landing_images`
--

CREATE TABLE `landing_images` (
  `id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `alt_text` varchar(255) NOT NULL DEFAULT 'Students',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `landing_images`
--

INSERT INTO `landing_images` (`id`, `image_path`, `display_order`, `alt_text`, `created_at`) VALUES
(11, 'assets/images/landing/5a59170b6f1907fd40dab621e4054b94.png', 5, 'Students', '2026-09-21 05:25:30');

-- --------------------------------------------------------

--
-- Table structure for table `online_requests`
--

CREATE TABLE `online_requests` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `student_number` varchar(50) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `program` varchar(255) DEFAULT NULL,
  `document_type` varchar(100) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email_address` varchar(128) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `student_id_image` varchar(255) DEFAULT NULL,
  `registration_form_image` varchar(255) DEFAULT NULL,
  `clearance_form_image` varchar(255) DEFAULT NULL,
  `proof_of_graduation_image` varchar(255) DEFAULT NULL,
  `id_picture_image` varchar(255) DEFAULT NULL,
  `honorable_dismissal_image` varchar(255) DEFAULT NULL,
  `government_id_image` varchar(255) DEFAULT NULL,
  `original_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image_2` varchar(255) DEFAULT NULL,
  `tor_request_type` enum('first_time','previous') DEFAULT NULL,
  `tor_previous_confirmed` tinyint(1) DEFAULT 0,
  `status` enum('pending','approved','disapproved') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `disapproval_reason` text DEFAULT NULL,
  `approved_request_id` int(11) DEFAULT NULL,
  `tracking_code` varchar(24) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `program` varchar(16) NOT NULL,
  `program_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`program`, `program_name`) VALUES
('BEEd', 'Bachelor in Elementary Education'),
('BSBA', 'Bachelor of Science in Business Administration'),
('BSCS', 'Bachelor of Science in Computer Science'),
('BSEd', 'Bachelor in Secondary Education'),
('BSFAS', 'BS in Fisheries and Aquatic Sciences'),
('BSHM', 'Bachelor of Science in Hospitality Management'),
('BSIT', 'Bachelor of Science in Information Technology'),
('LSHS', 'Laboratory Science High School'),
('TCP', 'Teacher Certificate Program');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `claiming_date` date DEFAULT NULL,
  `requester_id` int(11) DEFAULT NULL,
  `source` enum('walkin','online') NOT NULL DEFAULT 'walkin',
  `status` enum('pending','processing','for_signature','for_release','released') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `student_number` varchar(50) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT 0,
  `released_at` datetime DEFAULT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `email_address` varchar(128) DEFAULT NULL,
  `student_id_image` varchar(255) DEFAULT NULL,
  `registration_form_image` varchar(255) DEFAULT NULL,
  `clearance_form_image` varchar(255) DEFAULT NULL,
  `proof_of_graduation_image` varchar(255) DEFAULT NULL,
  `id_picture_image` varchar(255) DEFAULT NULL,
  `honorable_dismissal_image` varchar(255) DEFAULT NULL,
  `government_id_image` varchar(255) DEFAULT NULL,
  `original_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image` varchar(255) DEFAULT NULL,
  `photocopy_document_image_2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `id` int(11) NOT NULL,
  `staff_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`id`, `staff_name`, `is_deleted`) VALUES
(1, 'MJ', 0),
(2, 'Zyn', 0),
(3, 'Pearl', 0),
(4, 'TEst', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','staff','viewer') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$M9QSuWv3XDk8I1H2rqF0DOiVbtn3upp9OCnMSeAF9xETDPzZfT9bi', 'registrar@cvsu-naic.edu.ph', 'admin', '2025-08-01 02:14:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archive_history`
--
ALTER TABLE `archive_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requester_id` (`requester_id`);

--
-- Indexes for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `landing_images`
--
ALTER TABLE `landing_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `online_requests`
--
ALTER TABLE `online_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tracking_code` (`tracking_code`),
  ADD KEY `reviewed_by` (`reviewed_by`),
  ADD KEY `approved_request_id` (`approved_request_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`program`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requester_id` (`requester_id`);

--
-- Indexes for table `staffs`
--
ALTER TABLE `staffs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archive_history`
--
ALTER TABLE `archive_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_trail`
--
ALTER TABLE `audit_trail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `landing_images`
--
ALTER TABLE `landing_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `online_requests`
--
ALTER TABLE `online_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staffs`
--
ALTER TABLE `staffs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD CONSTRAINT `audit_trail_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `staffs` (`id`);

--
-- Constraints for table `online_requests`
--
ALTER TABLE `online_requests`
  ADD CONSTRAINT `online_requests_approved_request_fk2` FOREIGN KEY (`approved_request_id`) REFERENCES `requests` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `online_requests_reviewed_by_fk` FOREIGN KEY (`reviewed_by`) REFERENCES `staffs` (`id`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`requester_id`) REFERENCES `staffs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
