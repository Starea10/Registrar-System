<?php
/**
 * includes/upload-helper.php
 *
 * Shared server-side helper for validating and storing an uploaded
 * document image (student ID, registration form, government ID, etc.)
 * submitted through the online request form.
 *
 * This is the ONLY place in the project that touches $_FILES / writes an
 * uploaded file to disk (see Phase 0 note in
 * online-request-image-upload-plan.md: there was no existing upload code
 * anywhere before this). `submit-online-request.php` (Phase 5) calls
 * handle_document_upload() once per expected document field -- do not
 * duplicate this validation logic inline anywhere else.
 *
 * ---------------------------------------------------------------------
 * Upload directory assumption
 * ---------------------------------------------------------------------
 * There is no existing upload code or `uploads/` directory reference
 * anywhere in the codebase to inspect (grepped online-request.php,
 * request-online.php, submit-online-request.php, audit.php,
 * pending_request.js, request-online.js -- nothing). The plan's own
 * fallback example (`uploads/documents/`) is used here as the root.
 * If the real project already has a conventional uploads root elsewhere,
 * update UPLOAD_ROOT_RELATIVE below to match it -- everything else in
 * this file is agnostic to where that root actually is.
 */

// Root is relative to the project root (same directory submit-online-
// request.php lives in), and is also the relative path prefix that gets
// stored in the DB / used to build an <img src later>.
const UPLOAD_ROOT_RELATIVE = 'uploads/documents/';

// 5 MB, per the plan's Phase 2 step 2.
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

// Only real content types we accept, and the extension each maps to.
// Storage extension is always derived from the ACTUAL file content
// (finfo/getimagesize), never from the client-supplied name or MIME
// header -- see step 3 below.
const ALLOWED_IMAGE_TYPES = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
];

/**
 * Validate and store one uploaded document image.
 *
 * @param array  $file     A single element of $_FILES, e.g.
 *                         $_FILES['student_id_image'].
 * @param string $fieldKey Logical field name (matches the DB column /
 *                         form field name), used only in error messages.
 *
 * @return array{ok: bool, path?: string|null, error?: string}
 *   - No file was chosen for an optional field: ['ok' => true, 'path' => null]
 *   - Valid upload stored:                      ['ok' => true, 'path' => 'uploads/documents/xxxx.jpg']
 *   - Rejected / failed:                        ['ok' => false, 'error' => '...']
 */
function handle_document_upload(array $file, string $fieldKey): array
{
    // -------------------------------------------------------------
    // Step 1: no-file-uploaded vs a real error are different cases.
    // An empty/optional field (UPLOAD_ERR_NO_FILE, or the field
    // missing entirely) is NOT an error -- the caller decides
    // separately (Phase 5) whether that field was actually required
    // for the chosen document type.
    // -------------------------------------------------------------
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;

    if ($error === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'path' => null];
    }

    if ($error !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => upload_error_message($fieldKey, $error)];
    }

    $tmpPath = $file['tmp_name'] ?? '';
    if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
        // Defends against a crafted request that sets error=OK with a
        // tmp_name PHP didn't actually create via a real upload.
        return ['ok' => false, 'error' => "There was a problem receiving \"{$fieldKey}\". Please try uploading it again."];
    }

    // -------------------------------------------------------------
    // Step 2: size limit.
    // -------------------------------------------------------------
    $size = $file['size'] ?? filesize($tmpPath);
    if ($size > MAX_UPLOAD_BYTES) {
        $maxMb = number_format(MAX_UPLOAD_BYTES / (1024 * 1024), 0);
        return ['ok' => false, 'error' => "\"{$fieldKey}\" is too large. Please upload a file under {$maxMb}MB."];
    }
    if ($size <= 0) {
        return ['ok' => false, 'error' => "\"{$fieldKey}\" appears to be empty. Please choose a valid image file."];
    }

    // -------------------------------------------------------------
    // Step 4 (checked before content, since it's a cheap reject):
    // reject double extensions / anything on the ORIGINAL client
    // filename that isn't a plain .jpg/.jpeg/.png. This is defense
    // in depth on top of step 3 -- a file named "id.php.jpg" is
    // refused even before we look at its bytes, since some
    // misconfigured servers have been known to execute the
    // second-to-last extension in a dotted chain.
    // -------------------------------------------------------------
    $originalName = (string)($file['name'] ?? '');
    if (!has_single_safe_image_extension($originalName)) {
        return ['ok' => false, 'error' => "\"{$fieldKey}\" must be a single .jpg, .jpeg, or .png file."];
    }

    // -------------------------------------------------------------
    // Step 3: verify the ACTUAL file content, never trust
    // $_FILES[...]['type'] (that's just the browser's Content-Type
    // header, trivially spoofable) or the extension alone. This is
    // what stops a renamed .php file (or any non-image binary) with
    // a .jpg name from getting through.
    // -------------------------------------------------------------
    $detectedType = detect_real_image_type($tmpPath);
    if ($detectedType === null || !isset(ALLOWED_IMAGE_TYPES[$detectedType])) {
        return ['ok' => false, 'error' => "\"{$fieldKey}\" doesn't look like a valid JPEG or PNG image."];
    }

    // Storage extension comes from the verified content type, not from
    // whatever the client claimed.
    $ext = ALLOWED_IMAGE_TYPES[$detectedType];

    // -------------------------------------------------------------
    // Step 6: make sure the destination folder exists, and that its
    // .htaccess backstop is in place (step 7) before we write into it.
    // -------------------------------------------------------------
    $projectRoot = dirname(__DIR__);
    $uploadDirAbsolute = rtrim($projectRoot, '/') . '/' . UPLOAD_ROOT_RELATIVE;

    if (!is_dir($uploadDirAbsolute)) {
        if (!mkdir($uploadDirAbsolute, 0755, true) && !is_dir($uploadDirAbsolute)) {
            error_log("upload-helper: failed to create upload directory {$uploadDirAbsolute}");
            return ['ok' => false, 'error' => 'Something went wrong while saving your upload. Please try again.'];
        }
    }

    ensure_upload_dir_htaccess($uploadDirAbsolute);

    // -------------------------------------------------------------
    // Step 5: unique filename -- never the original filename, both
    // to prevent overwrites and to strip any path traversal /
    // executable-extension trickery in the original name.
    // -------------------------------------------------------------
    $generatedName = bin2hex(random_bytes(16)) . '.' . $ext;
    $destinationAbsolute = $uploadDirAbsolute . $generatedName;

    // Extremely unlikely with 16 random bytes, but don't silently
    // overwrite an existing file if it somehow collides.
    if (file_exists($destinationAbsolute)) {
        $generatedName = bin2hex(random_bytes(16)) . '.' . $ext;
        $destinationAbsolute = $uploadDirAbsolute . $generatedName;
    }

    if (!move_uploaded_file($tmpPath, $destinationAbsolute)) {
        error_log("upload-helper: move_uploaded_file failed for field \"{$fieldKey}\" -> {$destinationAbsolute}");
        return ['ok' => false, 'error' => "Something went wrong while saving \"{$fieldKey}\". Please try again."];
    }

    // -------------------------------------------------------------
    // Step 8: relative path (relative to project root), suitable for
    // storing in the DB column and for building an <img src> later.
    // -------------------------------------------------------------
    $relativePath = UPLOAD_ROOT_RELATIVE . $generatedName;

    return ['ok' => true, 'path' => $relativePath];
}

/**
 * Delete a previously-stored upload, given the relative path returned by
 * handle_document_upload(). Used by submit-online-request.php (Phase 5,
 * step 8) to clean up already-moved files if the DB insert fails after
 * files were written to disk, so no orphaned files are left behind.
 *
 * Safe to call with null/empty input (no-op) so callers can loop over
 * every field's result without checking each one first.
 */
function delete_uploaded_document(?string $relativePath): void
{
    if ($relativePath === null || $relativePath === '') {
        return;
    }

    // Only ever delete files inside our own upload root -- refuse
    // anything that looks like it's trying to escape it.
    $normalized = str_replace('\\', '/', $relativePath);
    if (
        strpos($normalized, UPLOAD_ROOT_RELATIVE) !== 0
        || strpos($normalized, '..') !== false
    ) {
        error_log("upload-helper: refused to delete suspicious path \"{$relativePath}\"");
        return;
    }

    $absolute = rtrim(dirname(__DIR__), '/') . '/' . $normalized;
    if (is_file($absolute)) {
        @unlink($absolute);
    }
}

// ===========================================================================
// Internal helpers
// ===========================================================================

/**
 * True only if $filename has exactly one extension and it's
 * .jpg / .jpeg / .png (case-insensitive) -- e.g. "id.jpg" passes,
 * "id.php.jpg", "id.jpg.php", and "id" (no extension) all fail.
 */
function has_single_safe_image_extension(string $filename): bool
{
    $filename = trim($filename);
    if ($filename === '') {
        return false;
    }

    // Strip any directory component a hostile client might have sent.
    $filename = basename(str_replace('\\', '/', $filename));

    $parts = explode('.', $filename);

    // "id.jpg" -> ["id", "jpg"] (2 parts, ok).
    // "id.php.jpg" -> ["id", "php", "jpg"] (3+ parts, reject).
    // "id" -> ["id"] (1 part, no extension, reject).
    // ".jpg" (empty basename before the dot) -> ["", "jpg"] -- also reject,
    // since real filenames from a file picker always have a name part.
    if (count($parts) !== 2 || $parts[0] === '') {
        return false;
    }

    $ext = strtolower($parts[1]);
    return in_array($ext, ['jpg', 'jpeg', 'png'], true);
}

/**
 * Determine the real content type of a file on disk by inspecting its
 * bytes -- never its name or client-supplied MIME header. Tries
 * fileinfo first (more reliable, detects any file type) and falls back
 * to getimagesize() if fileinfo isn't available on this host.
 *
 * @return string|null e.g. 'image/jpeg', or null if it can't be
 *                     determined / isn't a supported image.
 */
function detect_real_image_type(string $absolutePath): ?string
{
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo !== false) {
            $mime = finfo_file($finfo, $absolutePath);
            finfo_close($finfo);
            if (is_string($mime) && $mime !== '') {
                return $mime;
            }
        }
    }

    // Fallback: getimagesize() also reads actual image data (not just
    // the extension) and fails on non-images, so it's an acceptable
    // second layer if fileinfo is unavailable on this host.
    $info = @getimagesize($absolutePath);
    if ($info !== false && isset($info['mime'])) {
        return $info['mime'];
    }

    return null;
}

/**
 * Write (or confirm) an .htaccess in the upload directory that disables
 * script execution there. This is a defense-in-depth backstop on a
 * shared host where the upload directory can't be placed outside the
 * web-executable document root -- it is NOT a replacement for the real
 * content-type validation in detect_real_image_type() above.
 */
function ensure_upload_dir_htaccess(string $uploadDirAbsolute): void
{
    $htaccessPath = rtrim($uploadDirAbsolute, '/') . '/.htaccess';

    if (file_exists($htaccessPath)) {
        return;
    }

    $contents = <<<HTACCESS
# Auto-generated by includes/upload-helper.php.
# This folder only ever holds uploaded image files -- never allow any
# script to execute here, even if something slips past the content-type
# check in upload-helper.php.

# Apache 2.4+
<IfModule mod_php.c>
    php_flag engine off
</IfModule>
<IfModule mod_php7.c>
    php_flag engine off
</IfModule>

<FilesMatch "\.(php|phtml|php\d?|phar|cgi|pl|py|sh)$">
    Require all denied
</FilesMatch>

# Apache 2.2 fallback
<IfModule !mod_authz_core.c>
    <FilesMatch "\.(php|phtml|php\d?|phar|cgi|pl|py|sh)$">
        Order allow,deny
        Deny from all
    </FilesMatch>
</IfModule>

Options -ExecCGI
RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .phar
HTACCESS;

    // Best-effort: if this fails, detect_real_image_type() upstream is
    // still the primary defense, so we don't hard-fail the upload over
    // it -- but we do log it so it gets noticed.
    if (@file_put_contents($htaccessPath, $contents) === false) {
        error_log("upload-helper: failed to write .htaccess backstop in {$uploadDirAbsolute}");
    }
}

/**
 * Human-readable message for a PHP upload error code.
 */
function upload_error_message(string $fieldKey, int $errorCode): string
{
    switch ($errorCode) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return "\"{$fieldKey}\" is too large. Please upload a smaller file.";
        case UPLOAD_ERR_PARTIAL:
            return "\"{$fieldKey}\" was only partially uploaded. Please try again.";
        case UPLOAD_ERR_NO_TMP_DIR:
        case UPLOAD_ERR_CANT_WRITE:
        case UPLOAD_ERR_EXTENSION:
            error_log("upload-helper: server-side upload error {$errorCode} for field \"{$fieldKey}\"");
            return 'Something went wrong while receiving your upload. Please try again.';
        default:
            return "There was a problem with \"{$fieldKey}\". Please try uploading it again.";
    }
}